<?php 

	function listdl_init() {
		global $main;
	}

	function listdl_run() {
		global $main;
		#echo "<pre>".print_r($main->get('UI'),1);
	}

?>