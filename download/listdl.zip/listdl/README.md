### About ListDl Extension

Für alle, die gerne eine komplette Liste von Links haben, um alle Episoden von wget herunterzuladen,
einfach "listdl" und dein Audioformat wie folgt anhängen:

For all of you, who likes to have a complete list of links to download all episodes by wget
simply attach "listdl" and your audioformat like this:


##### Beispiel:

Den Link zur Liste aller Dateien eines Audioformats bekommst Du über `listdl` mit angehängtem Audioformat:

`http://democast.tld/demo/listdl/mp3`


##### Links:

- Github: [firtz extension: listdl](https://github.com/Firtz-Designs/QuorX-III)