<?php
/**
 * Created by PhpStorm.
 * User: McCouman
 * Date: 03.08.17
 * Time: 22:34
 */

function player_episode($item, $f) {
    global $f;
    $f->set('UI', 'ext/podlove-webplayer4/');
}


