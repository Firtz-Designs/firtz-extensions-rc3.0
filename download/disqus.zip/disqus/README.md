### About Disqus Extension

Diese Erweiterung bindet "disqus" als iframe in deine Podcast Episode ein.<br>
HörerInnen können sich so auf deinem Podcast zu Wort melden :)

##### Konfiguration:

Um die Erweiterung "disqus" für firtz nutzen zu können, benötigst du einen Account bei Disqus.
Gehe zur Konfiguration der Erweiterung unter `ext/disqus/ext.cfg` und trage deinen Benutzernamen ein.

**Beispiel:**
`username firtz`

##### Links:

- Website: [disqus.com](https://disqus.com)
- Github: [firtz extension: disquse](https://github.com/Firtz-Designs/QuorX-III)