<?php

function supporter_init()
{
    global $main;
}

function supporter_run()
{
    global $main;
}

?>