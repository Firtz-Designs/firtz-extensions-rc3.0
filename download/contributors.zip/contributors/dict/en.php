<?php
return array(
	'dict_contributors'=>'contributors',
	
);
?>