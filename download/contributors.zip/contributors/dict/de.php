<?php
return array(
	'dict_contributors'=>'Teilnehmer',
	
);
?>