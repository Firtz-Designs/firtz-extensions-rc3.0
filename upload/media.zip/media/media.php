<?php

function media_init()
{
    global $main;
}

function media_run()
{
    global $main;
}

?>