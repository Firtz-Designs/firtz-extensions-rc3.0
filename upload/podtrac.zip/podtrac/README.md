### About Podtrac Extension

Diese Erweiterung ändert die Feed links für den Dienst Podtrac.
Zur Nutzung benötigst du einen freien Zugang auf Podtrac.

##### Konfiguration:

Die Erweiterung befindet sich unter `ext/podtrac/ext.cfg`. Es sind keine weitere Angaben notwendig.


##### Links:

- Dienst: [podtrac.com](https://podtrac.com)
- Github: [firtz extension: podtrac](https://github.com/Firtz-Designs/QuorX-III)