### About JsonDl Extension

Diese Erweiterung ermöglicht eine offene Ausgabe alle Episoden über ein JSON Format.


##### Beispiel:

Den Link zur Liste aller Inhalte eines Audioformats bekommst Du über `jsondl` mit angehängten Audioformat:

`http://democast.tld/demo/jsondl/mp3`


##### Links:

- Info: [Json](http://www.json.org/json-de.html)
- Github: [firtz extension: jsondl](https://github.com/Firtz-Designs/QuorX-III)