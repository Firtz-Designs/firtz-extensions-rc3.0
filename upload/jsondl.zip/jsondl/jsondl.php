<?php

function jsondl_init()
{
    global $main;
}

function jsondl_run()
{
    global $main;
    #echo "<pre>".print_r($main->get('UI'),1);
}

?>